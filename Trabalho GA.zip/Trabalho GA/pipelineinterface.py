import tkinter as tk
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import functions as tgafunctions

#---------------------Funções Pirâmide--------------------------------
def desenhaPiramide2D(p):
    # p[i] = [x, y, z, w]


    def linha(i,j, cor):
        desenhaLinha(p[i][0], p[i][1], p[j][0], p[j][1], marker="o", color=cor)
    
     # Base
    linha(0, 1, "green")
    linha(1, 3, "green")
    linha(3, 2, "green")
    linha(2, 0, "green")

    # Laterais (até o topo)
    linha(0, 4, "blue")
    linha(1, 4, "blue")
    linha(2, 4, "blue")
    linha(3, 4, "blue")
    

    #p1(-0.5,-0.5,-0.5)
    #p2(-0.5,-0.5,0.5)
    #p5(0.5,-0.5,-0.5)
    #p6(0.5,-0.5,0.5)
    #p8(0.5,0.5,0.5)
    
    fig.canvas.draw()

def desenhaLinha(x1, y1, x2, y2, **parametros):
    plt.plot([x1, x2], [y1, y2], **parametros) 

def fazertudo(points, trans, view, proj):
    #transpõe os pontos para podermos multiplicar as matrizes por ele
    points = np.transpose(points)
    points = trans @ points
    points = view @ points
    points = proj @ points

    #4.1. Divide o x, y, z e w de cada ponto por w, para que o w volte a ser 1

    points = np.transpose(points)
    for i in range(len(points)):
        points[i] = points[i] / points[i][3]
 
    print("Coordenadas de projeção corrigidas pelo w:")
    print(points)

    fig.clear()

    plt.xlim(-1, 1)          # limite eixo X
    plt.ylim(-1, 1)          # limite eixo Y

    desenhaPiramide2D(points)

#----------------------Funções TKInter---------------------------------
def mostra_menu_principal(self):
    self.grid_remove()
    frame1.grid()

def mostra_menu_objeto(self):
    self.grid_remove()
    frame2.grid()

def mostra_menu_camera(self):
    self.grid_remove()
    frame3.grid()

def mostra_menu_projecao(self):
    self.grid_remove()
    frame4.grid()

def mostra_menu_mapeamento(self):
    self.grid_remove()
    frame5.grid()

def visualizarobjeto(self):
    self.grid_remove()
    frame6.grid()

def transformarobj(self):
    self.grid_remove()
    frame7.grid()    

def getvalues():
    x = float(xvar.get())
    y = float(yvar.get())
    z = float(zvar.get())

    return x, y, z
#-----------------------Início TKInter----------------------------------

# Initialize an instance of Tk
root = tk.Tk()
# Initialize matplotlib figure for graphing purposes
fig = plt.figure(1)
# Special type of "canvas" to allow for matplotlib graphing
canvas = FigureCanvasTkAgg(fig, master=root)
plot_widget = canvas.get_tk_widget()

initpoints = tgafunctions.inicializaMatriz()
inittrans = tgafunctions.geraMatrizTrasnformacao(1,1,0,1,1,1,0,0,0)
initview = tgafunctions.geraMatrizCamera(0, 0, 4, 0, -120, 0)
initproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

fazertudo(initpoints, inittrans, initview, initproj)

# Add the plot to the tkinter widget
plot_widget.grid(row=0, column=0)

#------------------------Frames TKInter----------------------------------

frame1 = tk.Frame(root)
frame2 = tk.Frame(root)
frame3 = tk.Frame(root)
frame4 = tk.Frame(root)
frame5 = tk.Frame(root)
frame6 = tk.Frame(root)
frame7 = tk.Frame(root)

#------------------------Frame1 (Menu Principal)-------------------------
tk.Label(frame1, text="Menu Principal").grid(row=1,column=1)
manip_obj_btn = tk.Button(frame1, text="Manipular Objeto", command= lambda: mostra_menu_objeto(frame1)).grid(row=2, column=1)
manip_cam_btn = tk.Button(frame1, text="Manipular a câmera", command=lambda: mostra_menu_camera(frame1)).grid(row=3, column=1)
manip_proj_btn = tk.Button(frame1, text="Modificar Projeção", command=lambda: mostra_menu_projecao(frame1)).grid(row=4, column=1)
mod_map__btn = tk.Button(frame1, text="Modificar Mapeamento", command=lambda: mostra_menu_mapeamento(frame1)).grid(row=5, column=1)
visual_obj_btn = tk.Button(frame1, text="Visualizar Objeto", command=lambda: visualizarobjeto(frame1)).grid(row=6, column=1)
frame1.grid()

#------------------------Frame2 (Menu Objeto)-----------------------------
tk.Label(frame2, text="Manipular Objeto").grid(row=1,column=1)
voltar_btn = tk.Button(frame2, text="Voltar", command= lambda: mostra_menu_principal(frame2)).grid(row=2,column=1)
trans_btn = tk.Button(frame2, text="Translação", command= lambda: transformarobj(frame2)).grid(row=3,column=1)
scale_btn = tk.Button(frame2, text="Escala").grid(row=4,column=1)
rot_x_btn = tk.Button(frame2, text="Rotação em X").grid(row=5,column=1)
rot_y_btn = tk.Button(frame2, text="Rotação em Y").grid(row=6,column=1)
rot_z_btn = tk.Button(frame2, text="Rotação em Z").grid(row=7,column=1)

#------------------------Frame3 (Menu Câmera)------------------------------
tk.Label(frame3, text="Manipular Câmera").grid(row=1,column=1)
voltar_btn = tk.Button(frame3, text="Voltar", command= lambda: mostra_menu_principal(frame3)).grid(row=2,column=1)
trans_btn = tk.Button(frame3, text="Translação").grid(row=3,column=1)
scale_btn = tk.Button(frame3, text="Escala").grid(row=4,column=1)
rot_x_btn = tk.Button(frame3, text="Rotação em X").grid(row=5,column=1)
rot_y_btn = tk.Button(frame3, text="Rotação em Y").grid(row=6,column=1)
rot_z_btn = tk.Button(frame3, text="Rotação em Z").grid(row=7,column=1)


#------------------------Frame4 (Menu Projeção)-----------------------------
tk.Label(frame4, text="Modificar Projeção").grid(row=1,column=1)
voltar_btn = tk.Button(frame4, text="Voltar", command= lambda: mostra_menu_principal(frame4)).grid(row=2,column=1)
proj_persp_btn = tk.Button(frame4, text="Projeção Perspectiva").grid(row=3,column=1)
proj_par_btn = tk.Button(frame4, text="Projeção Paralela").grid(row=4,column=1)

#------------------------Frame5 (Menu Mapeamento)----------------------------
tk.Label(frame5, text="Modificar Mapeamento").grid(row=1,column=1)
voltar_btn = tk.Button(frame5, text="Voltar", command= lambda: mostra_menu_principal(frame5)).grid(row=2,column=1)
window_btn = tk.Button(frame5, text="Window").grid(row=3,column=1)
viewport_btn = tk.Button(frame5, text="Viewport").grid(row=4,column=1)

#-----------------------Frame6 (Visualizar Objeto [Provavelmente não será usado])--------------------------------
tk.Label(frame6, text="Visualizar Objeto").grid(row=1,column=1)
voltar_btn = tk.Button(frame6, text="Voltar", command= lambda: mostra_menu_principal(frame6)).grid(row=2,column=1)
tk.Button(frame6,text="Esse botão terá uma função em algum momento no futuro.... ou não.").grid(row=3,column=1)

#-----------------------Frame7 (Transformações do Objeto)-------------------------------------------------------
tk.Label(frame7,text="Transformações do Objeto").grid(row=1,column=2)
voltar_btn = tk.Button(frame7, text="Voltar", command= lambda: mostra_menu_principal(frame7)).grid(row=2,column=2)

# Dropdown options  
transforms = ["Translação", "Escala", "Rotação em X", "Rotação em Y", "Rotação em Z"]
from tkinter import ttk
# Combobox  
transformoptions = ttk.Combobox(frame7, values=transforms)
transformoptions.set(transforms[0])
transformoptions.grid(row=3,column=2)


def getTransValues():

    x = float(xvar.get())
    y = float(yvar.get())
    z = float(zvar.get())

    points = tgafunctions.inicializaMatriz()
    newtrans = tgafunctions.geraMatrizTrasnformacao(x, y, z, 1, 1, 1, 1, 1, 1)
    pcam = tgafunctions.geraMatrizCamera(0, 0, 4, 0, -120, 0)
    pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

xvar=tk.StringVar()
yvar=tk.StringVar()
zvar=tk.StringVar()

xinput = tk.Entry(frame7, textvariable = xvar).grid(row=4,column=1)
yinput = tk.Entry(frame7, textvariable = yvar).grid(row=4,column=2)
zinput = tk.Entry(frame7, textvariable = zvar).grid(row=4,column=3)




tk.Button(frame7,text="Aplicar",command=getTransValues).grid(row=7,column=2)


root.mainloop()

