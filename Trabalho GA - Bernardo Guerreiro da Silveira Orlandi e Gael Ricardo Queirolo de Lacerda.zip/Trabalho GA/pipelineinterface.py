import tkinter as tk
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import functions as tgafunctions

matrizAcumula = ''
transAtual = ''
transParams = ''
camAtual = ''
camParams = ''
projAtual = "perspectiva"
limitex = [-1,1]
limitey = [-1,1]


#region-------------------------Funções Pirâmide-------------------------------------------------------------------------
def desenhaPiramide2D(p):
    # p[i] = [x, y, z, w]


    def linha(i,j, cor):
        desenhaLinha(p[i][0], p[i][1], p[j][0], p[j][1], marker="o", color=cor)
    
     # Base
    linha(0, 1, "green")
    linha(1, 3, "green")
    linha(3, 2, "green")
    linha(2, 0, "green")

    # Laterais (até o topo)
    linha(0, 4, "blue")
    linha(1, 4, "blue")
    linha(2, 4, "blue")
    linha(3, 4, "blue")
    

    #p1(-0.5,-0.5,-0.5)
    #p2(-0.5,-0.5,0.5)
    #p5(0.5,-0.5,-0.5)
    #p6(0.5,-0.5,0.5)
    #p8(0.5,0.5,0.5)
    
    fig.canvas.draw()

def desenhaLinha(x1, y1, x2, y2, **parametros):
    plt.plot([x1, x2], [y1, y2], **parametros) 

def fazertudo(points, trans, view, proj):
    #transpõe os pontos para podermos multiplicar as matrizes por ele
    global projAtual
    global camAtual
    global transAtual
    global limitex
    global limitey

    transAtual = trans
    camAtual = view

    points = np.transpose(points)
    points = trans @ points
    points = view @ points 
    points = proj @ points

    

        #Divide o x, y, z e w de cada ponto por w, para que o w volte a ser 1
    points = np.transpose(points)

    global matrizAcumula
    matrizAcumula = points + matrizAcumula
    for i in range(len(matrizAcumula)):
        matrizAcumula[i] = matrizAcumula[i] / matrizAcumula[i][3]

    print("Matriz Final = \n",matrizAcumula)

    fig.clear()

    plt.xlim(limitex[0], limitex[1])   
    plt.ylim(limitey[0], limitey[1])      

    
    desenhaPiramide2D(matrizAcumula)

def fazertudoinit(points, trans, view, proj):
    #transpõe os pontos para podermos multiplicar as matrizes por ele
    global projAtual
    global camAtual
    global transAtual
    global limitex
    global limitey
    
    transAtual = trans
    camAtual = view

    points = np.transpose(points)
    points = trans @ points
    points = view @ points
    points = proj @ points

    #Divide o x, y, z e w de cada ponto por w, para que o w volte a ser 1
    points = np.transpose(points)
    for i in range(len(points)):
        points[i] = points[i] / points[i][3]
 
    print("Coordenadas de projeção corrigidas pelo w:")
    print(points)

    fig.clear()
    
    plt.xlim(limitex[0], limitex[1])          # limite eixo X
    plt.ylim(limitey[0], limitey[1])          # limite eixo Y

    global matrizAcumula
    matrizAcumula = points
    
    print("Matriz = \n",matrizAcumula)
    desenhaPiramide2D(matrizAcumula)

#endregion

#region-------------------------Funções TKInter--------------------------------------------------------------------------
def mostra_menu_principal(self):
    self.grid_remove()
    frame1.grid()

def mostra_menu_objeto(self):
    self.grid_remove()
    frame2.grid()

def mostra_menu_camera(self):
    self.grid_remove()
    frame3.grid()

def mostra_menu_projecao(self):
    self.grid_remove()
    frame4.grid()

def mostra_menu_mapeamento(self):
    self.grid_remove()
    frame5.grid()

def visualizarobjeto(self):
    self.grid_remove()
    frame6.grid()

def mostra_menu_translacao_obj(self):
    self.grid_remove()
    frame7.grid()

def mostra_menu_escala_obj(self):
    self.grid_remove()
    frame8.grid()       

def mostra_menu_rotacao_obj(self):
    self.grid_remove()
    frame9.grid()       

def mostra_menu_translacao_cam(self):
    self.grid_remove()
    frame10.grid()

def mostra_menu_rotacao_cam(self):
    self.grid_remove()
    frame11.grid()

def mostra_menu_window(self):
    self.grid_remove()
    frame12.grid() 

def mostra_menu_viewport(self):
    self.grid_remove()
    frame13.grid() 

def getObjTransValues():
    global transAtual
    global transParams
    global camAtual
    x = float(otxvar.get())
    y = float(otyvar.get())
    z = float(otzvar.get())

    points = tgafunctions.inicializaMatriz()
    newtrans,tparams = tgafunctions.geraMatrizTrasnformacao(x, y, z, transParams[3], transParams[4], transParams[5], transParams[6], transParams[7], transParams[8])
    transParams = tparams
    pcam = camAtual
    global projAtual
    if projAtual == "perspectiva":
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    else:
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

def getObjScaleValues():
    global transAtual
    global transParams
    global camAtual
    x = float(osxvar.get())
    y = float(osyvar.get())
    z = float(oszvar.get())

    points = tgafunctions.inicializaMatriz()
    newtrans,tparams = tgafunctions.geraMatrizTrasnformacao(transParams[0], transParams[1], transParams[2], x, y, z, transParams[6], transParams[7], transParams[8])
    transParams = tparams
    pcam = camAtual
    global projAtual
    if projAtual == "perspectiva":
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    else:
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

def getObjRotationValues():
    global transAtual
    global transParams
    global camAtual
    x = float(orxvar.get())
    y = float(oryvar.get())
    z = float(orzvar.get())

    points = tgafunctions.inicializaMatriz()
    newtrans,tparams= tgafunctions.geraMatrizTrasnformacao(transParams[0], transParams[1], transParams[2], transParams[3], transParams[4], transParams[5], x, y, z)
    transParams = tparams
    pcam = camAtual
    global projAtual
    if projAtual == "perspectiva":
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    else:
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

def getCamTransValues():
    global transAtual
    global camAtual
    global camParams
    x = (float(ctxvar.get()) * -1)
    y = (float(ctyvar.get()) * -1)
    z = (float(ctzvar.get()) * -1)
    print("ctxyz = ", x, y, z)

    points = tgafunctions.inicializaMatriz()
    newtrans = transAtual
    pcam,cparams = tgafunctions.geraMatrizCamera(x, y, z, camParams[3], camParams[4], camParams[5])
    camParams = cparams
    global projAtual
    if projAtual == "perspectiva":
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    else:
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

def getCamRotationValues():
    global transAtual
    global camAtual
    global camParams
    x = (float(crxvar.get()) * -1)
    y = (float(cryvar.get()) * -1)
    z = (float(crzvar.get()) * -1)

    print("crxyz = ",x, y, z)

    points = tgafunctions.inicializaMatriz()
    newtrans = transAtual
    pcam,cparams = tgafunctions.geraMatrizCamera(camParams[0], camParams[1], camParams[2], x, y, z)
    camParams = cparams
    global projAtual
    if projAtual == "perspectiva":
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    else:
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
    
    fazertudo(points, newtrans, pcam, pproj)

def usarProjecaoPerspectiva():
    global projAtual
    global transAtual
    global camAtual
    global matrizAcumula
    if projAtual == "paralela":

        projAtual = "perspectiva"


        points = tgafunctions.inicializaMatriz()
        newtrans = transAtual
        pcam = camAtual
        pproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)
        fazertudo(points, newtrans,pcam,pproj)

    else:
        print("A projeção atual já é perspectiva.")

def usarProjecaoParalela():
    global projAtual
    global transAtual
    global camAtual
    global matrizAcumula
    if projAtual == "perspectiva":

        projAtual = "paralela"
    
        points = tgafunctions.inicializaMatriz()
        newtrans = transAtual
        pcam = camAtual
        pproj = tgafunctions.projecaoParalela(-1, 1, -1, 1, 0.1, 100)
        fazertudo(points,newtrans,pcam,pproj)
    else:
        print("A projeção atual já é paralela.")

def getWindowValues():
    wxmin = int(wxminvar.get())
    wxmax = int(wxmaxvar.get())
    wymin = int(wyminvar.get())
    wymax = int(wymaxvar.get())

    root.minsize(wxmin, wymin)
    root.maxsize(wxmax, wymax)

def getViewportValues():
    global projAtual
    global transAtual
    global camAtual
    global matrizAcumula
    global limitex
    global limitey

    vxmin = float(vxminvar.get())
    vxmax = float(vxmaxvar.get())
    vymin = float(vyminvar.get())
    vymax = float(vymaxvar.get())

    fig.clear()

    limitex = [vxmin,vxmax]
    limitey = [vymin,vymax]

    plt.xlim(limitex[0], limitex[1])   
    plt.ylim(limitey[0], limitey[1])   

    desenhaPiramide2D(matrizAcumula)

def reset():
    global transParams
    global camParams
    global projAtual
    global limitex
    global limitey

    initpoints = tgafunctions.inicializaMatriz()
    inittrans,tparams = tgafunctions.geraMatrizTrasnformacao(1,1,0,1,1,1,0,0,0)
    initview,cparams = tgafunctions.geraMatrizCamera(0, 0, 4, 0, -120, 0)
    initproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

    transParams = tparams
    camParams = cparams
    projAtual = "perspectiva"
    limitex = [-1,1]
    limitey = [-1,1]

    fazertudoinit(initpoints, inittrans, initview, initproj)


#endregion

#region-------------------------Início TKInter---------------------------------------------------------------------------

# Initialize an instance of Tk
root = tk.Tk()
# Initialize matplotlib figure for graphing purposes
fig = plt.figure(1)
# Special type of "canvas" to allow for matplotlib graphing
canvas = FigureCanvasTkAgg(fig, master=root)
plot_widget = canvas.get_tk_widget()

initpoints = tgafunctions.inicializaMatriz()
inittrans,tparams = tgafunctions.geraMatrizTrasnformacao(1,1,0,1,1,1,0,0,0)
initview,cparams = tgafunctions.geraMatrizCamera(0, 0, 4, 0, -120, 0)
initproj = tgafunctions.projecaoPerspectiva(70, 1.0, 0.1, 100)

transParams = tparams
camParams = cparams

fazertudoinit(initpoints, inittrans, initview, initproj)

# Add the plot to the tkinter widget
plot_widget.grid(row=0, column=0)

#endregion

#region-------------------------Frames TKInter---------------------------------------------------------------------------

 #region------------------------Criação das Frames-----------------------------------------------------------------------
frame1 = tk.Frame(root) #Menu Principal
frame2 = tk.Frame(root) #Menu Objeto
frame3 = tk.Frame(root) #Menu Câmera
frame4 = tk.Frame(root) #Menu Projeção
frame5 = tk.Frame(root) #Menu Mapeamento
frame6 = tk.Frame(root) #Reset
frame7 = tk.Frame(root) #Translação do Objeto
frame8 = tk.Frame(root) #Escala do Objeto
frame9 = tk.Frame(root) #Rotação do Objeto
frame10 = tk.Frame(root) #Translação da Câmera
frame11 = tk.Frame(root) #Rotação da Câmera
frame12 = tk.Frame(root) #Window
frame13 = tk.Frame(root) #Viewport
#endregion

 #region------------------------Frame1 (Menu Principal)------------------------------------------------------------------
tk.Label(frame1, text="Menu Principal").grid(row=1,column=1)
manip_obj_btn = tk.Button(frame1, text="Manipular Objeto", command= lambda: mostra_menu_objeto(frame1)).grid(row=2, column=1)
manip_cam_btn = tk.Button(frame1, text="Manipular a câmera", command=lambda: mostra_menu_camera(frame1)).grid(row=3, column=1)
manip_proj_btn = tk.Button(frame1, text="Modificar Projeção", command=lambda: mostra_menu_projecao(frame1)).grid(row=4, column=1)
mod_map__btn = tk.Button(frame1, text="Modificar Mapeamento", command=lambda: mostra_menu_mapeamento(frame1)).grid(row=5, column=1)
visual_obj_btn = tk.Button(frame1, text="Reset", command=lambda: visualizarobjeto(frame1)).grid(row=6, column=1)
frame1.grid()
# endregion

 #region------------------------Frame2 (Menu Objeto)---------------------------------------------------------------------
tk.Label(frame2, text="Manipular Objeto").grid(row=1,column=1)
voltar_btn = tk.Button(frame2, text="Voltar", command= lambda: mostra_menu_principal(frame2)).grid(row=2,column=1)
objtrans_btn = tk.Button(frame2, text="Translação", command= lambda: mostra_menu_translacao_obj(frame2)).grid(row=3,column=1)
objscale_btn = tk.Button(frame2, text="Escala",command= lambda: mostra_menu_escala_obj(frame2)).grid(row=4,column=1)
objrotbtn = tk.Button(frame2, text="Rotação",command= lambda: mostra_menu_rotacao_obj(frame2)).grid(row=5,column=1)

# endregion

 #region------------------------Frame3 (Menu Câmera)---------------------------------------------------------------------
tk.Label(frame3, text="Manipular Câmera").grid(row=1,column=1)
voltar_btn = tk.Button(frame3, text="Voltar", command= lambda: mostra_menu_principal(frame3)).grid(row=2,column=1)
trans_btn = tk.Button(frame3, text="Translação", command= lambda: mostra_menu_translacao_cam(frame3)).grid(row=3,column=1)
rot_x_btn = tk.Button(frame3, text="Rotação", command= lambda: mostra_menu_rotacao_cam(frame3)).grid(row=5,column=1)

# endregion

 #region------------------------Frame4 (Menu Projeção)-------------------------------------------------------------------
tk.Label(frame4, text="Modificar Projeção").grid(row=1,column=1)
voltar_btn = tk.Button(frame4, text="Voltar", command= lambda: mostra_menu_principal(frame4)).grid(row=2,column=1)
proj_persp_btn = tk.Button(frame4, text="Projeção Perspectiva", command= usarProjecaoPerspectiva).grid(row=3,column=1)
proj_par_btn = tk.Button(frame4, text="Projeção Paralela", command= usarProjecaoParalela).grid(row=4,column=1)
# endregion

 #region------------------------Frame5 (Menu Mapeamento)-----------------------------------------------------------------
tk.Label(frame5, text="Modificar Mapeamento").grid(row=1,column=1)
voltar_btn = tk.Button(frame5, text="Voltar", command= lambda: mostra_menu_principal(frame5)).grid(row=2,column=1)
window_btn = tk.Button(frame5, text="Window", command= lambda: mostra_menu_window(frame5)).grid(row=3,column=1)
viewport_btn = tk.Button(frame5, text="Viewport", command= lambda: mostra_menu_viewport(frame5)).grid(row=4,column=1)
#endregion

 #region------------------------Frame6 (Reset)--------------------------------
tk.Label(frame6, text="Resetar os valores da Pirâmide").grid(row=1,column=1)
voltar_btn = tk.Button(frame6, text="Voltar", command= lambda: mostra_menu_principal(frame6)).grid(row=2,column=1)
tk.Button(frame6,text="Aplicar",command=reset).grid(row=3,column=1)
#endregion

 #region------------------------Frame7 (Translação do Objeto)------------------------------------------------------------
tk.Label(frame7,text="Translação do Objeto").grid(row=1,column=2)
voltar_btn = tk.Button(frame7, text="Voltar", command= lambda: mostra_menu_objeto(frame7)).grid(row=2,column=2)

otxvar=tk.StringVar()
otyvar=tk.StringVar()
otzvar=tk.StringVar()

tk.Label(frame7,text="X").grid(row=3,column=1)
tk.Label(frame7,text="Y").grid(row=3,column=2)
tk.Label(frame7,text="Z").grid(row=3,column=3)

otxinput = tk.Entry(frame7, textvariable = otxvar).grid(row=4,column=1)
otyinput = tk.Entry(frame7, textvariable = otyvar).grid(row=4,column=2)
otzinput = tk.Entry(frame7, textvariable = otzvar).grid(row=4,column=3)

tk.Button(frame7,text="Aplicar",command=getObjTransValues).grid(row=7,column=2)

#endregion

 #region------------------------Frame8 (Escala do Objeto)----------------------------------------------------------------

tk.Label(frame8,text="Escala do Objeto").grid(row=1,column=2)
voltar_btn = tk.Button(frame8, text="Voltar", command= lambda: mostra_menu_objeto(frame8)).grid(row=2,column=2)
osxvar=tk.StringVar()
osyvar=tk.StringVar()
oszvar=tk.StringVar()

tk.Label(frame8,text="X").grid(row=3,column=1)
tk.Label(frame8,text="Y").grid(row=3,column=2)
tk.Label(frame8,text="Z").grid(row=3,column=3)

osxinput = tk.Entry(frame8, textvariable = osxvar).grid(row=4,column=1)
osyinput = tk.Entry(frame8, textvariable = osyvar).grid(row=4,column=2)
oszinput = tk.Entry(frame8, textvariable = oszvar).grid(row=4,column=3)

tk.Button(frame8,text="Aplicar",command=getObjScaleValues).grid(row=7,column=2)

#endregion

 #region------------------------Frame9 (Rotação do Objeto)---------------------------------------------------------------

tk.Label(frame9,text="Rotação do Objeto").grid(row=1,column=2)
voltar_btn = tk.Button(frame9, text="Voltar", command= lambda: mostra_menu_objeto(frame9)).grid(row=2,column=2)

orxvar=tk.StringVar()
oryvar=tk.StringVar()
orzvar=tk.StringVar()

tk.Label(frame9,text="X").grid(row=3,column=1)
tk.Label(frame9,text="Y").grid(row=3,column=2)
tk.Label(frame9,text="Z").grid(row=3,column=3)

orxinput = tk.Entry(frame9, textvariable = orxvar).grid(row=4,column=1)
oryinput = tk.Entry(frame9, textvariable = oryvar).grid(row=4,column=2)
orzinput = tk.Entry(frame9, textvariable = orzvar).grid(row=4,column=3)

tk.Button(frame9,text="Aplicar",command=getObjRotationValues).grid(row=7,column=2)

#endregion

 #region------------------------Frame10 (Translação da Câmera)------------------------------------------------------------
tk.Label(frame10,text="Translação da Câmera").grid(row=1,column=2)
voltar_btn = tk.Button(frame10, text="Voltar", command= lambda: mostra_menu_camera(frame10)).grid(row=2,column=2)

ctxvar=tk.StringVar()
ctyvar=tk.StringVar()
ctzvar=tk.StringVar()

tk.Label(frame10,text="X").grid(row=3,column=1)
tk.Label(frame10,text="Y").grid(row=3,column=2)
tk.Label(frame10,text="Z").grid(row=3,column=3)

ctxinput = tk.Entry(frame10, textvariable = ctxvar).grid(row=4,column=1)
ctyinput = tk.Entry(frame10, textvariable = ctyvar).grid(row=4,column=2)
ctzinput = tk.Entry(frame10, textvariable = ctzvar).grid(row=4,column=3)

tk.Button(frame10,text="Aplicar",command=getCamTransValues).grid(row=7,column=2)

#endregion

 #region------------------------Frame11 (Rotação da Câmera)---------------------------------------------------------------

tk.Label(frame11,text="Rotação da Câmera").grid(row=1,column=2)
voltar_btn = tk.Button(frame11, text="Voltar", command= lambda: mostra_menu_camera(frame11)).grid(row=2,column=2)

crxvar=tk.StringVar()
cryvar=tk.StringVar()
crzvar=tk.StringVar()

tk.Label(frame11,text="X").grid(row=3,column=1)
tk.Label(frame11,text="Y").grid(row=3,column=2)
tk.Label(frame11,text="Z").grid(row=3,column=3)

crxinput = tk.Entry(frame11, textvariable = crxvar).grid(row=4,column=1)
cryinput = tk.Entry(frame11, textvariable = cryvar).grid(row=4,column=2)
crzinput = tk.Entry(frame11, textvariable = crzvar).grid(row=4,column=3)

tk.Button(frame11,text="Aplicar",command=getCamRotationValues).grid(row=7,column=2)


#endregion

 #region------------------------Frame12 (Window)--------------------------------------------------------------------------
tk.Label(frame12,text="Window").grid(row=1,column=2)
voltar_btn = tk.Button(frame12, text="Voltar", command= lambda: mostra_menu_mapeamento(frame12)).grid(row=2,column=2)

wxminvar=tk.StringVar()
wxmaxvar=tk.StringVar()
wyminvar=tk.StringVar()
wymaxvar=tk.StringVar()

tk.Label(frame12,text="xmin").grid(row=3,column=1)
tk.Label(frame12,text="xmax").grid(row=3,column=2)
tk.Label(frame12,text="ymin").grid(row=3,column=3)
tk.Label(frame12,text="ymax").grid(row=3,column=4)

wxmininput = tk.Entry(frame12, textvariable = wxminvar).grid(row=4,column=1)
wxmaxinput = tk.Entry(frame12, textvariable = wxmaxvar).grid(row=4,column=2)
wymininput = tk.Entry(frame12, textvariable = wyminvar).grid(row=4,column=3)
wymaxinput = tk.Entry(frame12, textvariable = wymaxvar).grid(row=4,column=4)

tk.Button(frame12,text="Aplicar",command=getWindowValues).grid(row=7,column=2)

#endregion

 #region------------------------Frame13 (Viewport)--------------------------------------------------------------------------
tk.Label(frame13,text="Viewport").grid(row=1,column=2)
voltar_btn = tk.Button(frame13, text="Voltar", command= lambda: mostra_menu_mapeamento(frame13)).grid(row=2,column=2)

vxminvar=tk.StringVar()
vxmaxvar=tk.StringVar()
vyminvar=tk.StringVar()
vymaxvar=tk.StringVar()

tk.Label(frame13,text="xmin").grid(row=3,column=1)
tk.Label(frame13,text="xmax").grid(row=3,column=2)
tk.Label(frame13,text="ymin").grid(row=3,column=3)
tk.Label(frame13,text="ymax").grid(row=3,column=4)

vxmininput = tk.Entry(frame13, textvariable = vxminvar).grid(row=4,column=1)
vxmaxinput = tk.Entry(frame13, textvariable = vxmaxvar).grid(row=4,column=2)
vymininput = tk.Entry(frame13, textvariable = vyminvar).grid(row=4,column=3)
vymaxinput = tk.Entry(frame13, textvariable = vymaxvar).grid(row=4,column=4)

tk.Button(frame13,text="Aplicar",command=getViewportValues).grid(row=7,column=2)

#endregion

#endregion




root.mainloop()

