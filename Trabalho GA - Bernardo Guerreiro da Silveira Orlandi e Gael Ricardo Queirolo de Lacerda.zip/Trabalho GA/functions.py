import tkinter as tk
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

#----------------Funções da matriz de transformação, câmera e perspectiva----------------------------

def geraMatrizTrasnformacao(tx, ty, tz, sx, sy, sz, rx, ry, rz):
    #Matriz de translação
    T = np.array([[1, 0, 0, tx],
                  [0, 1, 0, ty],
                  [0, 0, 1, tz],
                  [0, 0, 0, 1]])
    
    #Matriz de escala
    S = np.array([[sx, 0, 0, 0],
                  [0, sy, 0, 0],
                  [0, 0, sz, 0],
                  [0, 0, 0, 1]])
    
    #Converte os angulos de graus pra radianos
    rx = np.radians(rx)
    ry = np.radians(ry)
    rz = np.radians(rz)

    #Matrizes de rotação
    Rx = np.array([ [1,     0,              0,          0],
                    [0,     np.cos(rx),    -np.sin(rx), 0],
                    [0,     np.sin(rx),    np.cos(rx),  0],
                    [0,     0,              0,          1]])
    
    Ry = np.array([ [np.cos(ry),    0, np.sin(ry),      0],
                    [0,             1, 0,               0],
                    [-np.sin(ry),   0, np.cos(ry),      0],
                    [0,             0, 0,               1]])
    
    Rz = np.array([ [np.cos(rz),   -np.sin(rz),     0,  0],
                    [np.sin(rz),    np.cos(rz),     0,  0],
                    [0,             0,              1,  0],
                    [0,             0,              0,  1]])
    
    
    #Combina todas as transformações em uma única matriz por meio de multiplicação de matrizes
    combinacao = S @ Rz @ Ry @ Rx @ T
    params = [tx,ty,tz,sx,sy,sz,rx,ry,rz]

    return combinacao, params

def geraMatrizCamera(camx, camy, camz, camrx, camry, camrz):
    #Matriz de translação da câmera
    T = np.array([[1, 0, 0, -camx],
                  [0, 1, 0, -camy],
                  [0, 0, 1, -camz],
                  [0, 0, 0, 1]])
    
    #Converte os angulos de graus pra radianos
    camrx = np.radians(camrx)
    camry = np.radians(camry)
    camrz = np.radians(camrz)

    #Matrizes de rotação
    Rx = np.array([ [1,     0,                  0,              0],
                    [0,     np.cos(-camrx),    -np.sin(-camrx), 0],
                    [0,     np.sin(-camrx),    np.cos(-camrx),  0],
                    [0,     0,                  0,              1]])
    
    Ry = np.array([ [np.cos(-camry),    0, np.sin(-camry),     0],
                    [0,                 1, 0,                  0],
                    [-np.sin(-camry),   0, np.cos(-camry),     0],
                    [0,                 0, 0,                  1]])
    
    Rz = np.array([ [np.cos(-camrz),   -np.sin(-camrz),     0,  0],
                    [np.sin(-camrz),    np.cos(-camrz),     0,  0],
                    [0,                 0,                  1,  0],
                    [0,                 0,                  0,  1]])
    
    combinacao = T @ Rz @ Ry @ Rx 
    params = [camx,camy,camz,camrx,camry,camrz]

    return combinacao, params

def projecaoPerspectiva(fovy, aspect, znear, zfar):
    fovy = np.radians(fovy)

    a = 1/(np.tan(fovy/2)*aspect)
    b = 1/np.tan(fovy/2)
    c = (zfar+znear)/(znear-zfar)
    d = (2*zfar*znear)/(znear-zfar)

    p = np.array([[a, 0, 0,  0],
                  [0, b, 0,  0],
                  [0, 0, c,  d],
                  [0, 0, -1, 0]])
    
    return p

def projecaoParalela(left, right, bottom, top, znear, zfar):

    p = np.array([[2/(right-left), 0, 0, -(right+left)/(right-left)],
                  [0, 2/(top-bottom), 0, -(top+bottom)/(top-bottom)],
                  [0, 0, -2/(zfar-znear), -(zfar+znear)/(zfar-znear)],
                  [0, 0, 0, 1]])
    
    return p
        
#---------------------Função que cria uma matriz no valor padrão-------------------------------------

def inicializaMatriz():
    matriz = np.array([[-0.5, -0.5, -0.5, 1],   #p1
                   [-0.5, -0.5, 0.5, 1],    #p2
                   [0.5, -0.5, -0.5, 1],    #p5
                   [0.5, -0.5, 0.5, 1],     #p6
                   [0.0, 0.5, 0.0, 1]])     #p8
    return matriz

